put things in EGEtools/include/ into (Visual Studio)/VC/Tools/MSVC/(version)/include/
same with things in EGEtools/lib/
